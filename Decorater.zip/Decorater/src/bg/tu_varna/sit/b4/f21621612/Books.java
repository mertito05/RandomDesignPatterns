package bg.tu_varna.sit.b4.f21621612;

abstract class Books {
    protected Page page;
    protected Text txt;
    protected Book price;
    protected BookResume resume;
    public Books(Page page,Text txt,Book price,BookResume resume){
        this.page=page;
        this.txt=txt;
        this.price=price;
        this.resume=resume;
    }
    abstract public void applyPage();
    abstract public void setText();
    abstract public void applyPrice();
    abstract public void applyResume();

}

