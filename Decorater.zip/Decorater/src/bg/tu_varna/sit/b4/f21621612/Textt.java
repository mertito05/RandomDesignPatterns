package bg.tu_varna.sit.b4.f21621612;

class Textt implements Text{
    @Override
    public void setText() {
        System.out.println("Something random");
    }
}
