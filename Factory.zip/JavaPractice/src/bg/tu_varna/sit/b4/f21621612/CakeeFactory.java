package bg.tu_varna.sit.b4.f21621612;

class CakeeFactory {
    public static PastryRecipe getCakee(CakeFactory factory){
        return factory.createPastry();
    }

}
