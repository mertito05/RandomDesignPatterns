package bg.tu_varna.sit.b4.f21621612;

public class EklerrFactory {
    public static PastryRecipe getEklerr(EklerFactory factory){
        return factory.createPastry();
    }
}
