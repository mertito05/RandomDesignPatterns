package bg.tu_varna.sit.b4.f21621612;

class SoftCoverDecorator extends BookDecorator{
    private int mass;

    public SoftCoverDecorator(DBook dBook) {
        super(dBook);
    }

    @Override
    public String getCover() {
        return super.getCover()+addSoftCover()+addMass();
    }
    private String addSoftCover(){
        return "\nSoft cover";
    }

    public int addMass() {
        return mass;
    }
}
