package bg.tu_varna.sit.b4.f21621612;

class Pages implements Page{
    @Override
    public void applyPage() {
        System.out.println(300);
    }
}
