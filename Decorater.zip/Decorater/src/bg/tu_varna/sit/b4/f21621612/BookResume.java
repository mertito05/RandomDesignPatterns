package bg.tu_varna.sit.b4.f21621612;

interface BookResume {
    public void applyResume();
}
