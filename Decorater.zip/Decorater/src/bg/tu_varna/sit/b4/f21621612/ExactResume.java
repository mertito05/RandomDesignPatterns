package bg.tu_varna.sit.b4.f21621612;

class ExactResume implements BookResume{
    @Override
    public void applyResume() {
        System.out.println("This is not a resume");
    }
}
