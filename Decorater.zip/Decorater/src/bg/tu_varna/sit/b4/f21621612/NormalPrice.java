package bg.tu_varna.sit.b4.f21621612;

class NormalPrice implements Book{

    @Override
    public void applyPrice() {
        System.out.println(30);
    }
}
