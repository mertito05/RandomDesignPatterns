package bg.tu_varna.sit.b4.f21621612;

class DBookImp implements DBook{
    @Override
    public String getCover() {
        return "Book has: ";
    }
}
