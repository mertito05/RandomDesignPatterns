package bg.tu_varna.sit.b4.f21621612;

abstract class PastryRecipe {
    public abstract String getDough();
    public abstract String getFilling();
    public abstract String getGlaze();
    public abstract int getLayers();
    public abstract String getCream();

    @Override
    public String toString() {
        return "PastryRecipe{"+this.getDough()+this.getFilling()+this.getGlaze()+this.getLayers()+this.getCream()+"}";
    }
}
