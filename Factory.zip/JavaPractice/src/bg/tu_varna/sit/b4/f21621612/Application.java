package bg.tu_varna.sit.b4.f21621612;

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
            testFactory();
        }
        private static void testFactory(){
            PastryRecipe cake=CakeeFactory.getCakee(new CakeFactory())
            PastryRecipe donut=DonuttFactory.getDonutt(new DonutFactory())
            PastryRecipe ekler=EklerrFactory.getEklerr(new EklerFactory())
            PastryRecipe medenki=MedenkiiFactory.getMedenkii(new MedenkiFactory())
            System.out.println("Cake: "+cake);
            System.out.println("Donut: "+donut);
            System.out.println("Ekler: "+ekler);
            System.out.println("Medenki: "+medenki);
        }
    }
