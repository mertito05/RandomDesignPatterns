package bg.tu_varna.sit.b4.f21621612;

class HardCoverDecorator extends BookDecorator{
    private String podvurzia;
    public HardCoverDecorator(DBook dBook) {
        super(dBook);
    }

    @Override
    public String getCover() {
        return super.getCover() +addHardCover()+addPodvurzia();

    }
    private String addHardCover(){
        return "\nHard cover";
    }
    public String addPodvurzia(){
        return podvurzia;
    }
}
