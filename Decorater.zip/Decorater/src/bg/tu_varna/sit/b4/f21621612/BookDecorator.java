package bg.tu_varna.sit.b4.f21621612;

abstract class BookDecorator implements DBook{
    private DBook dBook;

    public BookDecorator(DBook dBook) {
        this.dBook = dBook;
    }
    public String getCover(){

        return dBook.getCover();
    }
}
