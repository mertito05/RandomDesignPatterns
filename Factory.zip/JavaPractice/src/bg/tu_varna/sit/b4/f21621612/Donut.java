package bg.tu_varna.sit.b4.f21621612;

class Donut extends PastryRecipe{
    private String dough;
    private String filling;
    private String glaze;
    private int layers;
    private String cream;

    public Donut(String dough, String filling, String glaze, int layers, String cream) {
        this.dough = dough;
        this.filling = filling;
        this.glaze = glaze;
        this.layers = layers;
        this.cream = cream;
    }

    @Override
    public String getDough() {
        return dough;
    }

    @Override
    public String getFilling() {
        return filling;
    }

    @Override
    public String getGlaze() {
        return glaze;
    }

    @Override
    public int getLayers() {
        return layers;
    }

    @Override
    public String getCream() {
        return cream;
    }
}
