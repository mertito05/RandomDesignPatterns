package bg.tu_varna.sit.b4.f21621612;

public class Application {
    public static void main(String[] args) {
        Books eBook=new EBook(new Pages(),new Textt(),new NormalPrice(),new ExactResume());
        eBook.applyPrice();
        eBook.applyPage();
        eBook.applyResume();
        eBook.setText();

        Books normalBook=new PhysicalBook(new Pages(),new Textt(),new DiscountedPrice(),new ExactResume());
        normalBook.applyPrice();
        normalBook.applyResume();
        normalBook.applyPage();
        normalBook.setText();

        DBook dBook=new DBookImp();
        DBook firstBook=new HardCoverDecorator(dBook);
        System.out.println("First"+firstBook.getCover()+"\n");
        DBook secondBook=new SoftCoverDecorator(dBook);
        System.out.println("Second"+secondBook.getCover()+"\n");

    }

}