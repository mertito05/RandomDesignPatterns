package bg.tu_varna.sit.b4.f21621612;

public class DonuttFactory {
    public static PastryRecipe getDonutt(DonutFactory factory){
        return factory.createPastry();
    }
}
