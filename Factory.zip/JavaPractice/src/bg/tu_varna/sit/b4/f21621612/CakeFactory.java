package bg.tu_varna.sit.b4.f21621612;

public class CakeFactory implements _CreatePastry{
    private String dough;
    private String filling;
    private String glaze;
    private int layers;
    private String cream;

    public CakeFactory(String dough, String filling, String glaze, int layers, String cream) {
        this.dough = dough;
        this.filling = filling;
        this.glaze = glaze;
        this.layers = layers;
        this.cream = cream;
    }

    @Override
    public PastryRecipe createPastry() {
        return new Cake(dough,filling,glaze,layers,cream);
    }
}
