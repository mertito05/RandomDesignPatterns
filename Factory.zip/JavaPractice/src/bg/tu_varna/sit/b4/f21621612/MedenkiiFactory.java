package bg.tu_varna.sit.b4.f21621612;

public class MedenkiiFactory {
    public static PastryRecipe getMedenkii(MedenkiFactory factory){
        return factory.createPastry();
    }
}
