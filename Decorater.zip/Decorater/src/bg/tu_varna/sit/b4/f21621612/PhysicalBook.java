package bg.tu_varna.sit.b4.f21621612;

class PhysicalBook extends Books{

    public PhysicalBook(Page page, Text txt, Book price, BookResume resume) {
        super(page, txt, price, resume);
    }

    @Override
    public void applyPage() {
        page.applyPage();
    }

    @Override
    public void setText() {
        txt.setText();
    }

    @Override
    public void applyPrice() {
        price.applyPrice();
    }

    @Override
    public void applyResume() {
        resume.applyResume();
    }
}
